typedef struct Token {
    int count;
    int oper;
    int value;
} token;