typedef struct Count {
    int count;
    int value;
} count;